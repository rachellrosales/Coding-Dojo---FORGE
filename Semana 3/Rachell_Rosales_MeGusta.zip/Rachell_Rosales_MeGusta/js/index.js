let like = document.querySelectorAll(".boton-like")

for(let i = 0; i < like.length; i++){
    like[i].addEventListener("click", function(){
        let numeroLikes = this.closest('.likes').querySelector('.numero');
        let contadorLikes = Number(numeroLikes.innerText);

        contadorLikes++;
        numeroLikes.innerText = contadorLikes;
    })
}
